# shorts-bot

Scripts in `queue.json` -> TTS voiceover -> captioned 9:16 video (FFmpeg) -> private upload scheduled via `publishAt`.

## Setup
1. Install Node 18+ and FFmpeg (`ffmpeg`, `ffprobe` on PATH).
2. `npm install`, copy `.env.example` to `.env`, fill in keys.
3. Put licensed/own background clips in `assets/backgrounds/` (e.g. `pitch.mp4`).
4. Google Cloud: enable YouTube Data API v3, create an OAuth client (Web), add redirect `http://localhost:3000/oauth2callback`, then `npm run auth` and paste the refresh token into `.env`.

## Weekly routine
1. Add ~7 scripts to `queue.json` (status `pending`).
2. `npm run dry` to check the renders in `out/`.
3. `npm run weekly` to upload and schedule one per day.
4. Skim the scheduled videos in YouTube Studio.

## Notes
- New API projects are locked to private until Google audits them: submit the audit form before expecting public scheduled uploads. Quota allows only a few uploads/day.
- Set the AI/synthetic content disclosure in Studio where it applies.
- Use only background footage and music you have the rights to.
- Vary formats and scripts: repetitive templated videos risk demonetisation.
