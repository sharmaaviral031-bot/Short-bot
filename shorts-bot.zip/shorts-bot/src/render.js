import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import { tts } from './tts.js';

const run = promisify(execFile);

const sentences = (t) =>
  (t.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || []).map((s) => s.trim()).filter(Boolean);

function wrap(text, width = 20) {
  const lines = [];
  let line = '';
  for (const w of text.split(/\s+/)) {
    if ((line + ' ' + w).trim().length > width) { lines.push(line.trim()); line = w; }
    else line += ' ' + w;
  }
  if (line.trim()) lines.push(line.trim());
  return lines.join('\n');
}

async function duration(file) {
  const { stdout } = await run('ffprobe', [
    '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file,
  ]);
  return parseFloat(stdout);
}

// One segment per sentence: audio + background + caption, so captions stay in sync.
export async function render(item, workDir, outFile) {
  await fs.mkdir(workDir, { recursive: true });
  const bg = path.resolve('assets/backgrounds', item.background);
  const font = process.env.FONT_FILE;
  const segs = [];

  for (const [i, sentence] of sentences(item.script).entries()) {
    const audio = path.join(workDir, `s${i}.mp3`);
    const txt = path.join(workDir, `s${i}.txt`);
    const seg = path.join(workDir, `s${i}.mp4`);
    await tts(sentence, audio);
    await fs.writeFile(txt, wrap(sentence));
    const dur = (await duration(audio)) + 0.2;

    const vf =
      'scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,' +
      `drawtext=fontfile=${font}:textfile=${txt}:fontsize=68:fontcolor=white:` +
      'borderw=6:bordercolor=black:line_spacing=12:x=(w-text_w)/2:y=(h-text_h)/2';

    await run('ffmpeg', [
      '-y', '-stream_loop', '-1', '-i', bg, '-i', audio, '-t', dur.toFixed(2),
      '-vf', vf, '-af', 'apad', '-map', '0:v', '-map', '1:a',
      '-r', '30', '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-ar', '44100', '-ac', '2', seg,
    ]);
    segs.push(seg);
  }

  const list = path.join(workDir, 'list.txt');
  await fs.writeFile(list, segs.map((s) => `file '${path.resolve(s)}'`).join('\n'));
  await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', outFile]);
  return outFile;
}
