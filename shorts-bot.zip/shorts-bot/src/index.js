import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { render } from './render.js';
import { upload } from './upload.js';

const dry = process.argv.includes('--dry');
const perRun = Number(process.env.VIDEOS_PER_RUN || 7);
const hour = Number(process.env.PUBLISH_HOUR_UTC || 13);

const queue = JSON.parse(await fs.readFile('queue.json', 'utf8'));
const todo = queue.filter((q) => q.status === 'pending').slice(0, perRun);
if (!todo.length) { console.log('Queue empty: add more scripts to queue.json'); process.exit(0); }

// First slot: tomorrow at PUBLISH_HOUR_UTC, one per day after that.
// If you run this weekly, start after your last scheduled date.
const start = new Date();
start.setUTCDate(start.getUTCDate() + 1);
start.setUTCHours(hour, 0, 0, 0);

for (const [i, item] of todo.entries()) {
  const out = path.resolve('out', `${item.id}.mp4`);
  console.log(`Rendering ${item.id}: ${item.title}`);
  await render(item, path.resolve('out', `work-${item.id}`), out);
  if (dry) { console.log('  dry run, skipping upload:', out); continue; }

  const when = new Date(start.getTime() + i * 86400000).toISOString();
  const videoId = await upload(out, item, when);
  item.status = 'scheduled';
  item.videoId = videoId;
  item.publishAt = when;
  console.log(`  scheduled for ${when} (https://youtu.be/${videoId})`);
  await fs.writeFile('queue.json', JSON.stringify(queue, null, 2));
}
