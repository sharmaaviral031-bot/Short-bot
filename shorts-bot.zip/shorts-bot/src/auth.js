// One-time: run `npm run auth`, open the URL, approve, copy the refresh token into .env
import 'dotenv/config';
import http from 'node:http';
import { google } from 'googleapis';

const auth = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  'http://localhost:3000/oauth2callback'
);
const url = auth.generateAuthUrl({
  access_type: 'offline',
  prompt: 'consent',
  scope: ['https://www.googleapis.com/auth/youtube.upload'],
});
console.log('Open this URL:\n', url);

http
  .createServer(async (req, res) => {
    const code = new URL(req.url, 'http://localhost:3000').searchParams.get('code');
    if (!code) return res.end('No code');
    const { tokens } = await auth.getToken(code);
    console.log('\nGOOGLE_REFRESH_TOKEN=' + tokens.refresh_token);
    res.end('Done. You can close this tab.');
    process.exit(0);
  })
  .listen(3000);
