import { google } from 'googleapis';
import fs from 'node:fs';

function youtube() {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    'http://localhost:3000/oauth2callback'
  );
  auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
  return google.youtube({ version: 'v3', auth });
}

// Uploads as private with a publishAt time: YouTube publishes it automatically.
export async function upload(file, item, publishAt) {
  const yt = youtube();
  const res = await yt.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: {
        title: item.title.slice(0, 100),
        description: item.description,
        tags: item.tags,
        categoryId: '17', // Sports; change to match your niche
      },
      status: {
        privacyStatus: 'private',
        publishAt,
        selfDeclaredMadeForKids: false,
      },
    },
    media: { body: fs.createReadStream(file) },
  });
  return res.data.id;
}
