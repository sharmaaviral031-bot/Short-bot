import fs from 'node:fs/promises';

// Returns path to an mp3 for the given text. Swap this file for another provider if you like.
export async function tts(text, outFile) {
  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${process.env.ELEVEN_VOICE_ID}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': process.env.ELEVEN_API_KEY,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2' }),
    }
  );
  if (!res.ok) throw new Error(`TTS failed: ${res.status} ${await res.text()}`);
  await fs.writeFile(outFile, Buffer.from(await res.arrayBuffer()));
  return outFile;
}
